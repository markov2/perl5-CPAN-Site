#!/usr/bin/perl

no punctuation;

print "I like pie.\n";

$x = 1;
$^W = 1;

